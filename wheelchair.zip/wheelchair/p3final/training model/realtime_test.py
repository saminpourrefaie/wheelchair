import cv2
import numpy as np
import os
import mediapipe as mp
from tensorflow.keras.models import load_model
import joblib

# تنظیمات MediaPipe
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# توابع کمکی
def mediapipe_detection(image, hands):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image.flags.writeable = False
    results = hands.process(image)
    image.flags.writeable = True
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    return image, results

def draw_styled_landmarks(image, results):
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(
                image, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2),
                mp_drawing.DrawingSpec(color=(0, 0, 255), thickness=2)
            )

def extract_keypoints(results):
    keypoints = []
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            hand = np.array([[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark]).flatten()
            keypoints.append(hand)
    else:
        keypoints.append(np.zeros(21*3))

    while len(keypoints) < 2:
        keypoints.append(np.zeros(21*3))
    
    return np.concatenate(keypoints)

#S

def prob_viz(res, actions, image, colors):
    output_frame = image.copy()
    for num, prob in enumerate(res):
        
        cv2.rectangle(output_frame, (5, 65 + num * 45), (int(prob * 100) + 5, 95 + num * 45), (50, 50, 50), -1)  # سایه
        cv2.rectangle(output_frame, (0, 60 + num * 45), (int(prob * 100), 90 + num * 45), colors[num % len(colors)], -1)
        cv2.putText(output_frame, f"{actions[num]}: {prob:.2f}", (10, 85 + num * 45), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA)
    return output_frame

# بارگذاری مدل و scaler
model = load_model('action.keras')
scaler = joblib.load('scaler.pkl')
sequence_length = 20
actions = np.array(['hello', 'thanks', 'iloveyou', 'My', 'name is', 'nice', 'to meet you', 'how are', 'you', 'Ready?', 'No'])
colors = [
    (245, 117, 16), (117, 245, 16), (16, 117, 245),
    (245, 16, 117), (117, 16, 245), (245, 245, 16),
    (16, 245, 245), (245, 16, 245), (16, 245, 16),
    (245, 117, 245), (117, 245, 117)
]

# آستانه اطمینان
threshold = 0.8

# شروع webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()


with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5, max_num_hands=2) as hands:
    sequence = []
    sentence = []
    predictions = []
    clear_flash = False  

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame.")
            break

        # تشخیص دست با MediaPipe
        image = cv2.flip(frame, 1)  # آینه کردن 
        image, results = mediapipe_detection(image, hands)
        draw_styled_landmarks(image, results)

        # استخراج نقاط کلیدی
        keypoints = extract_keypoints(results)
        if keypoints.shape != (126,):
            print(f"Warning: Invalid keypoints shape {keypoints.shape}, padding with zeros")
            keypoints = np.zeros(126)
        sequence.append(keypoints)
        sequence = sequence[-sequence_length:]

        # پیش‌بینی زمانی که دنباله کامل شد
        if len(sequence) == sequence_length:
            try:
                res = np.array(sequence)
                if res.shape != (sequence_length, 126):
                    print(f"Error: Expected shape ({sequence_length}, 126), got {res.shape}")
                    res = np.zeros((sequence_length, 126))
                res = res.reshape(1, sequence_length, 126)
                res = scaler.transform(res.reshape(-1, 126)).reshape(1, sequence_length, 126)
                res = model.predict(res)
                predictions.append(np.argmax(res))
                # محاسبه احتمال حداکثر
                max_prob = np.max(res)
                predicted_action = actions[np.argmax(res)]

                # چاپ و نمایش پیش‌بینی
                print(f"Predicted action (prob={max_prob:.2f}): {predicted_action}")
                if max_prob > threshold:
                    if len(sentence) > 0 and predicted_action != sentence[-1]:
                        sentence.append(predicted_action)
                    elif len(sentence) == 0:
                        sentence.append(predicted_action)

                if len(sentence) > 5:
                    sentence = sentence[-5:]

                # نمایش احتمالای
                image = prob_viz(res[0], actions, image, colors)

            except Exception as e:
                print(f"Prediction error: {e}")
                continue

        
        height, width, _ = image.shape
        cv2.rectangle(image, (15, 15), (width - 15, 60), (50, 50, 50), -1)  # سایه
        cv2.rectangle(image, (10, 10), (width - 10, 55), (45, 20, 80), -1)  # پس‌زمینه تیره
        cv2.putText(image, 'Sentence: ' + ' '.join(sentence), (20, 40),
                    cv2.FONT_HERSHEY_DUPLEX, 1.2, (200, 200, 255), 2, cv2.LINE_AA)

        if clear_flash:
            cv2.rectangle(image, (10, 10), (width - 10, 55), (0, 255, 0), 2)  # حاشیه سبز
            clear_flash = False

        cv2.putText(image, "Instructions: Gesture, 'q' to quit, 'c' to clear", (10, height - 20),
                    cv2.FONT_HERSHEY_DUPLEX, 0.8, (150, 150, 200), 2, cv2.LINE_AA)

        cv2.imshow('Hand Gesture Recognition', cv2.resize(image, (1000, 700)))  # اندازه بزرگ‌تر

        key = cv2.waitKey(10) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('c'):
            sentence = []  
            clear_flash = True  
            print("Sentence cleared!")

    cap.release()
    cv2.destroyAllWindows()
    