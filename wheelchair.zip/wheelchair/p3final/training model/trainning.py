import numpy as np
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import TensorBoard, EarlyStopping
from sklearn.metrics import multilabel_confusion_matrix, accuracy_score
import joblib
import tensorflow as tf


np.random.seed(42)

tf.random.set_seed(42)

DATA_PATH = os.path.join('MP_Data')
actions = np.array(['hello', 'thanks', 'iloveyou','My','name is','nice','to meet you','how are','you','Ready?','No'])
no_sequences = 20
sequence_length = 20


label_map = {label: num for num, label in enumerate(actions)} # مپ میکنه از ۰ تا ۱
sequences, labels = [], []
for action in actions:
    action_path = os.path.join(DATA_PATH, action)
    if not os.path.exists(action_path):
        print(f"Action path not found: {action_path}")
        continue
    sequence_dirs = [d for d in os.listdir(action_path) if d.isdigit() and os.path.isdir(os.path.join(action_path, d))]
    for sequence in np.array(sequence_dirs).astype(int):
        window = []
        sequence_path = os.path.join(action_path, str(sequence))
        if not os.path.exists(sequence_path):
            print(f"Sequence path not found: {sequence_path}")
            continue
        for frame_num in range(sequence_length):
            npy_path = os.path.join(sequence_path, f"{frame_num}.npy")
            if os.path.exists(npy_path):
                res = np.load(npy_path)
                if res.size == 0 or res.shape != (126,):
                    print(f"Invalid file: {npy_path}, shape = {res.shape if res.size > 0 else 'empty'}")
                    break
                window.append(res)
            else:
                print(f"File not found: {npy_path}")
                break
        if len(window) == sequence_length:
            sequences.append(window)
            labels.append(label_map[action])
        else:
            print(f"Incomplete sequence: {sequence_path}, frames = {len(window)}")

if not sequences:
    raise ValueError("No valid sequences found in MP_Data. Check the directory structure.")

# تبدیل به آرایه NumPy
X = np.array(sequences)
y = to_categorical(labels).astype(int)


print(f"X shape: {X.shape}")
print(f"y shape: {y.shape}")


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)  

# نرمال‌سازی داده‌ها
scaler = StandardScaler()
X_train_reshaped = X_train.reshape(-1, X_train.shape[-1])
X_train = scaler.fit_transform(X_train_reshaped).reshape(X_train.shape)
X_test_reshaped = X_test.reshape(-1, X_test.shape[-1])
X_test = scaler.transform(X_test_reshaped).reshape(X_test.shape)

# ذخیره scaler
joblib.dump(scaler, 'scaler.pkl')


model = Sequential()
model.add(LSTM(64, return_sequences=True, activation='tanh', input_shape=(20, 126)))
model.add(Dropout(0.3))
model.add(LSTM(32, return_sequences=False, activation='tanh'))
model.add(Dropout(0.3))
model.add(Dense(64, activation='relu'))
model.add(Dense(actions.shape[0], activation='softmax'))

model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])

# آموزش مدل
log_dir = os.path.join('Logs')
tb_callback = TensorBoard(log_dir=log_dir)
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

history = model.fit(
    X_train, y_train,
    epochs=100, 
    validation_data=(X_test, y_test),
    callbacks=[tb_callback, early_stopping],
    batch_size=16
)


plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(history.history['categorical_accuracy'], label='Training Accuracy')
plt.plot(history.history['val_categorical_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

plt.show()

# پیش‌بینی و ارزیابی
res = model.predict(X_test)
print("Predicted action:", actions[np.argmax(res[0])])
print("True action:", actions[np.argmax(y_test[0])])

# ذخیره مدل
model.save('action.keras')

# ارزیابی بیشتر
yhat = model.predict(X_test)
ytrue = np.argmax(y_test, axis=1).tolist()
yhat = np.argmax(yhat, axis=1).tolist()
print("Confusion Matrix:", multilabel_confusion_matrix(ytrue, yhat))
print("Accuracy:", accuracy_score(ytrue, yhat))